.. module:: dns.asyncresolver
.. _async_resolver:

Stub Resolver
=============

Dnspython's asyncresolver module implements an asynchronous "stub resolver".

.. toctree::

   async-resolver-class
   async-resolver-functions
