.. _community:

Community
=========

Bugs and Feature Requests
-------------------------

Bugs and feature requests can be made using the github issues system at
`github <https://github.com/rthalley/dnspython/issues>`_.

Mailing Lists
-------------

| `dnspython-announce <https://groups.google.com/group/dnspython-announce>`_
| `dnspython-users <https://groups.google.com/group/dnspython-users>`_
| `dnspython-dev <https://groups.google.com/group/dnspython-dev>`_
