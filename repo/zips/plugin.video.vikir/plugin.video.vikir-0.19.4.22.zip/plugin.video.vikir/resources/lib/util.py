#  -*- coding: utf-8 -*-
def convertLang(sublang):
    if sublang == '0':
        return 'en'
    elif sublang == '1':
        return 'bg'
    elif sublang == '2':
        return 'es'
    elif sublang == '3':
        return 'fr'
    elif sublang == '4':
        return 'pt'
    elif sublang == '5':
        return 'ja'
    elif sublang == '6':
        return 'zh'  # lang = 'zh-cn'
    elif sublang == '7':
        return 'tw'  # lang = 'zh-tw'
    elif sublang == '8':
        return 'ko'
    elif sublang == '9':
        return 'ab'
    elif sublang == '10':
        return 'aa'
    elif sublang == '11':
        return 'af'
    elif sublang == '12':
        return 'ak'
    elif sublang == '13':
        return 'am'
    elif sublang == '14':
        return 'ag'
    elif sublang == '15':
        return 'az'
    elif sublang == '16':
        return 'ms'
    elif sublang == '17':
        return 'id'
    elif sublang == '18':
        return 'jv'
    elif sublang == '19':
        return 'bn'
    elif sublang == '20':
        return 'bo'
    elif sublang == '21':
        return 'bs'
    elif sublang == '22':
        return 'ca'
    elif sublang == '23':
        return 'ch'
    elif sublang == '24':
        return 'ce'
    elif sublang == '25':
        return 'za'
    elif sublang == '26':
        return 'cy'
    elif sublang == '27':
        return 'da'
    elif sublang == '28':
        return 'de'
    elif sublang == '29':
        return 'dv'
    elif sublang == '30':
        return 'dz'
    elif sublang == '31':
        return 'et'
    elif sublang == '32':
        return 'eo'
    elif sublang == '33':
        return 'eu'
    elif sublang == '34':
        return 'to'
    elif sublang == '35':
        return 'ga'
    elif sublang == '36':
        return 'sm'
    elif sublang == '37':
        return 'gl'
    elif sublang == '38':
        return 'gd'
    elif sublang == '39':
        return 'hm'
    elif sublang == '40':
        return 'hr'
    elif sublang == '41':
        return 'ia'
    elif sublang == '42':
        return 'it'
    elif sublang == '43':
        return 'mu'
    elif sublang == '44':
        return 'cb'
    elif sublang == '45':
        return 'kw'
    elif sublang == '46':
        return 'km'
    elif sublang == '47':
        return 'rn'
    elif sublang == '48':
        return 'sw'
    elif sublang == '49':
        return 'hat'
    elif sublang == '50':
        return 'ku'
    elif sublang == '51':
        return 'lo'
    elif sublang == '52':
        return 'la'
    elif sublang == '53':
        return 'lv'
    elif sublang == '54':
        return 'lt'
    elif sublang == '55':
        return 'hu'
    elif sublang == '56':
        return 'mg'
    elif sublang == '57':
        return 'ml'
    elif sublang == '58':
        return 'mo'
    elif sublang == '59':
        return 'my'
    elif sublang == '60':
        return 'fj'
    elif sublang == '61':
        return 'nl'
    elif sublang == '62':
        return 'cr'
    elif sublang == '63':
        return 'no'
    elif sublang == '64':
        return 'or'
    elif sublang == '65':
        return 'uz'
    elif sublang == '66':
        return 'pl'
    elif sublang == '67':
        return 'ro'
    elif sublang == '68':
        return 'rm'
    elif sublang == '69':
        return 'st'
    elif sublang == '70':
        return 'sq'
    elif sublang == '71':
        return 'sk'
    elif sublang == '72':
        return 'sl'
    elif sublang == '73':
        return 'so'
    elif sublang == '74':
        return 'sh'
    elif sublang == '75':
        return 'fi'
    elif sublang == '76':
        return 'sv'
    elif sublang == '77':
        return 'tl'
    elif sublang == '78':
        return 'tt'
    elif sublang == '79':
        return 'vi'
    elif sublang == '80':
        return 'tw'
    elif sublang == '81':
        return 'tr'
    elif sublang == '82':
        return 'wo'
    elif sublang == '83':
        return 'yo'
    elif sublang == '84':
        return 'sn'
    elif sublang == '85':
        return 'lol'
    elif sublang == '86':
        return 'tm'
    elif sublang == '87':
        return 'is'
    elif sublang == '88':
        return 'cs'
    elif sublang == '89':
        return 'el'
    elif sublang == '90':
        return 'ba'
    elif sublang == '91':
        return 'mk'
    elif sublang == '92':
        return 'mn'
    elif sublang == '93':
        return 'ru'
    elif sublang == '94':
        return 'sr'
    elif sublang == '95':
        return 'uk'
    elif sublang == '96':
        return 'mne'
    elif sublang == '97':
        return 'kk'
    elif sublang == '98':
        return 'hy'
    elif sublang == '99':
        return 'he'
    elif sublang == '100':
        return 'ar'
    elif sublang == '101':
        return 'ur'
    elif sublang == '102':
        return 'skr'
    elif sublang == '103':
        return 'fa'
    elif sublang == '104':
        return 'hne'
    elif sublang == '105':
        return 'ne'
    elif sublang == '106':
        return 'mr'
    elif sublang == '107':
        return 'sa'
    elif sublang == '108':
        return 'hi'
    elif sublang == '109':
        return 'pa'
    elif sublang == '110':
        return 'gu'
    elif sublang == '111':
        return 'ta'
    elif sublang == '112':
        return 'te'
    elif sublang == '113':
        return 'kn'
    elif sublang == '114':
        return 'th'
    elif sublang == '115':
        return 'yue'
    else:
        return 'eng'