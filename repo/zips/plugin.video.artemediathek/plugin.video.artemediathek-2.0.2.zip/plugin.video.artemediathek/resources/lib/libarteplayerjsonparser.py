# -*- coding: utf-8 -*-
import requests
import json
from . import libmediathek4utils as lm4utils

class PlayerParser:
	def __init__(self):
		self.lang = lm4utils._setLang()
		self.playerURL = 'https://api.arte.tv/api'
		self.generalUrl = 'https://static-cdn.arte.tv/static/artevp/5.2.2/config/json/general.json'

	def parseVideo(self,programId):
		d = {}
		j = requests.get(self.generalUrl).json()
		headers = {'Authorization': f'Bearer {j["apiplayer"]["token"]}'}
		j = requests.get(f'{self.playerURL}/player/v2/config/{self.lang}/{programId}', headers=headers).json()
		for item in j['data']['attributes']['streams']:
			lm4utils.log(str(item))
			if "HLS" in item['protocol']:
				d[item['versions'][0]['shortLabel']] = item['url']
		
		return {'media':[{'url':j['data']['attributes']['streams'][0]['url'], 'stream':'HLS'}]}#fallback