# -*- coding: utf-8 -*-
from resources.lib import libarte

arte = libarte.libarte()
arte.action()