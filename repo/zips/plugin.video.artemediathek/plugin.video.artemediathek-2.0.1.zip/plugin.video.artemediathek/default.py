# -*- coding: utf-8 -*-
from lib import libarte

arte = libarte.libarte()
arte.action()