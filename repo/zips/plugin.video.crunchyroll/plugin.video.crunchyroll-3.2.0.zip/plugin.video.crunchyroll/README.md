# Crunchyroll plugin for Kodi

Crunchyroll a KODI (XBMC) plugin for Crunchyroll.com.

Git repo: https://github.com/MrKrabat/plugin.video.crunchyroll

Forum posting: xxx

**WARNING: You MUST be a PREMIUM member to use this plugin!**
***

What this plugin currently can do:
- [x] Supports all Crunchyroll regions
- [x] Login with your account
- [x] Search for animes
- [x] Browse all featured anime/drama
- [x] Browse all popular anime/drama
- [x] Browse all simulcasts
- [x] Browse all updated anime/drama
- [x] Browse all new anime/drama
- [x] Browse all anime/drama alphabetically
- [x] Browse all genres
- [x] Browse all seasons
- [x] View queue/playlist
- [x] View history
- [ ] View random anime/drama
- [x] View all seasons/arcs of an anime/drama
- [x] View all episodes of an season/arc
- [x] Context menue "Goto series" and "Goto season"
- [ ] Add or remove anime/drama from your queue/playlist
- [x] Display various informations
- [x] Watch videos with premium subscription
- [x] Synchronizes playback stats with Crunchyroll
***

_This website and addon is not affiliated with Crunchyroll._

_Kodi® (formerly known as XBMC™) is a registered trademark of the XBMC Foundation.
This website and addon is not affiliated with Kodi, Team Kodi, or the XBMC Foundation._